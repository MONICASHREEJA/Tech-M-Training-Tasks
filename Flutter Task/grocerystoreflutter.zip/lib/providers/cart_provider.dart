import 'package:flutter/material.dart';
import '../models/product.dart';
import '../database/database_helper.dart';

class CartProvider with ChangeNotifier {
  final List<Product> _cartItems = [];
  List<Product> _products = [];

  List<Product> get cartItems => _cartItems;
  List<Product> get products => _products;

  Future<void> fetchProducts() async {
    _products = await DatabaseHelper.instance.fetchProducts();
    notifyListeners();
  }

  void addProduct(Product product) async {
    await DatabaseHelper.instance.insertProduct(product);
    _products.add(product);
    notifyListeners();
  }

  void addToCart(Product product) {
    _cartItems.add(product);
    notifyListeners();
  }

  void removeFromCart(Product product) {
    _cartItems.remove(product);
    notifyListeners();
  }

  double get totalPrice => _cartItems.fold(0, (sum, item) => sum + item.price);
}

