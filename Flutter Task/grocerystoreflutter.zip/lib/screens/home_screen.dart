import 'package:flutter/material.dart';
import 'product_list.dart';
import 'add_product.dart';
import 'cart_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Grocery Store')),
      body: Center(child: const Text('Welcome to Grocery Store')),
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.green),
              child: Text('Menu', style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            ListTile(
              title: const Text('Products'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductListScreen())),
            ),
            ListTile(
              title: const Text('Add Product'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddProductScreen())),
            ),
            ListTile(
              title: const Text('Cart'),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartScreen())),
            ),
          ],
        ),
      ),
    );
  }
}
